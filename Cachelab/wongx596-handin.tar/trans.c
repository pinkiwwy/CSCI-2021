/*
 * Name: Wing Yi Wong
 * login ID: wongx596
 */

/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
     int i, j;
     int temp[12] = {0}; //for 64*64 matrix. Different way than 32*32 or 61*67

     int r_count;
     int c_count;
 
     int r_block = 0;
     int c_block = 0;
     
     int diagonal, temp_d = 0;
     
     if (M == 61)
       {
	 r_block = 14;
	 c_block = 14;
       }
     else if (M == 32)
       {
	 r_block = 8;
	 c_block = 8;
       }
     if (M == 61 || M == 32){
     for (i = 0; i < N; i += c_block)
       {
	 for (j = 0; j < M; j += r_block)
	   {
	     for (c_count = i; (c_count < N) && (c_count < i + c_block); ++ c_count)
	       {
		 for (r_count = j; (r_count < M) && (r_count < j + r_block); ++ r_count)
		   {
		     if (c_count == r_count)
		       {
			 temp_d = A[r_count][r_count];
			 diagonal = r_count;
		       }
		     else
		       {
			 B[r_count][c_count] = A[c_count][r_count];
		       }
		   }
		 if (i == j && c_count < N)
		   B[diagonal][diagonal] = temp_d;
	       }
	   }
       }
     }

     /*for 64x64, I process the matrix by 8x8 block
     *In each block, divide to four 4x4 block(upper left, upper right, lower left, lower right
     *In this way, easier to solve
     */
     else if (M == 64)
       {
         for (temp[0] = 0; temp[0] < 64; temp[0] += 8)
	   {
	     for (temp[1] = 0; temp[1] < 64; temp[1] += 8)
	       {
		 for (temp[2] = temp[1]; temp[2] < temp[1] + 4; temp[2] ++)
		   {
		      
		     temp[3] = A[temp[2]][temp[0]];
		     temp[4] = A[temp[2]][temp[0]+1];
		     temp[5] = A[temp[2]][temp[0]+2];
		     temp[6] = A[temp[2]][temp[0]+3];
		     
		     temp[7] = A[temp[2]][temp[0]+4];
		     temp[8] = A[temp[2]][temp[0]+5];
		     temp[9] = A[temp[2]][temp[0]+6];
		     temp[10] = A[temp[2]][temp[0]+7];
 
		     B[temp[0]][temp[2]] = temp[3];
		     B[temp[0]+1][temp[2]] = temp[4];
		     B[temp[0]+2][temp[2]] = temp[5];
		     B[temp[0]+3][temp[2]] = temp[6];
		     
		     B[temp[0]][temp[2]+4] = temp[7];
		     B[temp[0]+1][temp[2]+4] = temp[8];
		     B[temp[0]+2][temp[2]+4] = temp[9];
		     B[temp[0]+3][temp[2]+4] = temp[10];
		   }

		 for (temp[3] = temp[0] + 4; temp[3] < temp[0] + 8; temp[3] ++)
		   {
		     temp[4] = B[temp[3]-4][temp[1]+4];
		     temp[5] = B[temp[3]-4][temp[1]+5];
		     temp[6] = B[temp[3]-4][temp[1]+6];
		     temp[7] = B[temp[3]-4][temp[1]+7];
		     
		     B[temp[3]-4][temp[1]+4] = A[temp[1]+4][temp[3]-4];
		     B[temp[3]-4][temp[1]+5] = A[temp[1]+5][temp[3]-4];
		     B[temp[3]-4][temp[1]+6] = A[temp[1]+6][temp[3]-4];
		     B[temp[3]-4][temp[1]+7] = A[temp[1]+7][temp[3]-4];
		     
		     B[temp[3]][temp[1]] = temp[4];
		     B[temp[3]][temp[1]+1] = temp[5];
		     B[temp[3]][temp[1]+2] = temp[6];
		     B[temp[3]][temp[1]+3] = temp[7];
		    
		     B[temp[3]][temp[1]+4] = A[temp[1]+4][temp[3]];
		     B[temp[3]][temp[1]+5] = A[temp[1]+5][temp[3]];
		     B[temp[3]][temp[1]+6] = A[temp[1]+6][temp[3]];
		     B[temp[3]][temp[1]+7] = A[temp[1]+7][temp[3]];
		   }
	       }
	   }
       }
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

